import java.util.Scanner;

class BankAccount {
    private double balance;

    public BankAccount(double balance) {
        this.balance = balance;
    }

    public boolean deposit(double amount) {
        if (amount > 0) {
            this.balance += amount;
            return true;
        } else {
            System.out.println("Invalid deposit amount.");
            return false;
        }
    }

    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= this.balance) {
            this.balance -= amount;
            return true;
        } else {
            System.out.println("Invalid withdrawal amount or insufficient funds.");
            return false;
        }
    }

    public double checkBalance() {
        return this.balance;
    }
}

class ATM {
    private BankAccount account;

    public ATM(BankAccount account) {
        this.account = account;
    }

    public void displayOptions() {
        System.out.println("ATM Options:");
        System.out.println("1. Withdraw");
        System.out.println("2. Deposit");
        System.out.println("3. Check Balance");
        System.out.println("4. Exit");
    }

    public double validateAmount(String input) {
        try {
            double amount = Double.parseDouble(input);
            if (amount > 0) {
                return amount;
            } else {
                System.out.println("Invalid amount. Please enter a positive value.");
                return -1;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid number.");
            return -1;
        }
    }

    public void performTransaction(int option) {
        Scanner scanner = new Scanner(System.in);

        switch (option) {
            case 1:  // Withdraw
                System.out.print("Enter withdrawal amount: ");
                double withdrawAmount = validateAmount(scanner.nextLine());
                if (withdrawAmount != -1) {
                    if (account.withdraw(withdrawAmount)) {
                        System.out.println("Withdrawal successful. Remaining balance: $" + account.checkBalance());
                    } else {
                        System.out.println("Withdrawal failed.");
                    }
                }
                break;

            case 2:  // Deposit
                System.out.print("Enter deposit amount: ");
                double depositAmount = validateAmount(scanner.nextLine());
                if (depositAmount != -1) {
                    if (account.deposit(depositAmount)) {
                        System.out.println("Deposit successful. New balance: $" + account.checkBalance());
                    } else {
                        System.out.println("Deposit failed.");
                    }
                }
                break;

            case 3:  // Check Balance
                double balance = account.checkBalance();
                System.out.println("Your current balance: $" + balance);
                break;

            case 4:  // Exit
                System.out.println("Thank you for using the ATM. Goodbye!");
                System.exit(0);
                break;

            default:
                System.out.println("Invalid option. Please choose a valid option (1-4).");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        BankAccount userAccount = new BankAccount(1000);
        ATM atm = new ATM(userAccount);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            atm.displayOptions();
            System.out.print("Enter your choice (1-4): ");
            String userOption = scanner.nextLine();

            if (userOption.equalsIgnoreCase("exit")) {
                break;
            }

            try {
                int option = Integer.parseInt(userOption);
                if (option >= 1 && option <= 4) {
                    atm.performTransaction(option);
                } else {
                    System.out.println("Invalid input. Please enter a number between 1 and 4.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 4 or 'exit'.");
            }
        }
    }
}
