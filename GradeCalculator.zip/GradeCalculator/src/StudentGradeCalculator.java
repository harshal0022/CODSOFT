import java.util.Scanner;

public class StudentGradeCalculator {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);

        System.out.print("Please enter the student's name: ");
        String studentName = inputScanner.nextLine();

        System.out.print("Enter the number of subjects: ");
        int numberOfSubjects = inputScanner.nextInt();

        int totalMarks = 0;
        int maximumMarks = numberOfSubjects * 100; // Assuming each subject has a maximum of 100 marks

        for (int i = 1; i <= numberOfSubjects; i++) {
            System.out.print("Enter marks for Subject " + i + ": ");
            int subjectMarks = inputScanner.nextInt();
            totalMarks += subjectMarks;
        }

        double percentage = (double) totalMarks / maximumMarks * 100;

        char grade;
        if (percentage >= 90) {
            grade = 'A';
        } else if (percentage >= 80) {
            grade = 'B';
        } else if (percentage >= 70) {
            grade = 'C';
        } else if (percentage >= 60) {
            grade = 'D';
        } else {
            grade = 'F';
        }

        System.out.println("\nStudent Name: " + studentName);
        System.out.println("Total Marks: " + totalMarks + " out of " + maximumMarks);
        System.out.println("Percentage: " + String.format("%.2f", percentage) + "%");
        System.out.println("Grade: " + grade);

        inputScanner.close();
    }
}
