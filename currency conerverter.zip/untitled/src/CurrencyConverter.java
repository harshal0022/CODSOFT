import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class CurrencyConverter {

    private static final String API_KEY = "f4993b0b938a0ece4c80b3a7";
    private static final String API_URL = "https://v6.exchangerate-api.com/v6/" + API_KEY + "/latest/";

    public static void main(String[] args) {
        try {
            // Step 1: Allow the user to choose the base and target currencies
            System.out.print("Enter the base currency code (e.g., USD): ");
            String baseCurrency = getUserInput();
            System.out.print("Enter the target currency code (e.g., EUR): ");
            String targetCurrency = getUserInput();

            // Step 2: Fetch real-time exchange rates
            String exchangeRateAPIUrl = API_URL + baseCurrency;
            String jsonResponse = getApiResponse(exchangeRateAPIUrl);

            // Step 3: Parse the JSON response to get the exchange rate
            double exchangeRate = parseExchangeRate(jsonResponse, targetCurrency);

            // Step 4: Take input from the user for the amount to convert
            System.out.print("Enter the amount to convert: ");
            double amountToConvert = Double.parseDouble(getUserInput());

            // Step 5: Convert the amount using the fetched exchange rate
            double convertedAmount = amountToConvert * exchangeRate;

            // Step 6: Display the result to the user
            System.out.println("Converted amount: " + convertedAmount + " " + targetCurrency);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String getUserInput() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        return reader.readLine();
    }

    private static String getApiResponse(String apiUrl) throws IOException {
        URL url = new URL(apiUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        int responseCode = connection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            return response.toString();
        } else {
            throw new IOException("Failed to fetch exchange rates. HTTP error code: " + responseCode);
        }
    }

    private static double parseExchangeRate(String jsonResponse, String targetCurrency) {
        // Parse the JSON response to get the exchange rate for the target currency
        // This is a simplified example, and you may want to use a JSON library for production code
        int targetCurrencyIndex = jsonResponse.indexOf(targetCurrency);
        int rateIndex = jsonResponse.indexOf("rate", targetCurrencyIndex);
        int endIndex = jsonResponse.indexOf(",", rateIndex);

        String rateString = jsonResponse.substring(rateIndex + 6, endIndex);
        return Double.parseDouble(rateString);
    }
}
